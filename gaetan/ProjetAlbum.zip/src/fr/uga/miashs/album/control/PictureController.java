package fr.uga.miashs.album.control;


import java.net.URI;
import java.net.URISyntaxException;
import java.nio.file.Path;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.inject.Inject;
import javax.inject.Named;

import fr.uga.miashs.album.model.Album;
import fr.uga.miashs.album.model.Picture;
import fr.uga.miashs.album.service.PictureService;

@Named
@ManagedBean
@ViewScoped
public class PictureController {
	
    @Inject
    private PictureService pictureService;
    
    
    private Picture selectedPicture;
    
    
    public PictureController(){

    }
    
    @PostConstruct
    public void init(){
    	selectedPicture = new Picture();
    }
    
    public Picture getSelectedPicture() {
        return selectedPicture;
    }
 
    public void setSelectedPicture(Picture selectedCar) {
        this.selectedPicture = selectedCar;
    }

    public void createPicture(Path path, String filename, Album album) {
    	System.out.println("debut create picture");
    	Picture picture = new Picture();
		picture.setAlbum(album);
		picture.setTitle(filename);
		picture.setLocalfile(path.toString());
		String id = "http://www.semanticweb.org/picture/"+album.getId()+"/"+filename;
		try {
			URI uri = new URI(id);
			picture.setUri(uri);
		} catch (URISyntaxException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
    
	public void deletePictureById(long pictureId){
		System.out.println("delete picture");
		System.out.println(pictureId);
		pictureService.deleteById(pictureId);
	}
		    
}
