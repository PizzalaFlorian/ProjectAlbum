package fr.uga.miashs.album.service;

import javax.persistence.Query;

import fr.uga.miashs.album.model.Picture;

public class PictureService extends JpaService<Long,Picture> {


	public void create(Picture pic) throws ServiceException {
        pic.setAlbum(getEm().merge( pic.getAlbum()));
        super.create(pic);
    }  
    
    public Picture getById(Integer id) {
        Query query = getEm().createNamedQuery("Picture.findById");
        query.setParameter("id", id);
        return (Picture) query.getSingleResult();
    }

}
