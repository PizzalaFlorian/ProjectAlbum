package fr.uga.miashs.album.service;

import java.util.List;

import javax.persistence.Query;

import fr.uga.miashs.album.model.Album;
import fr.uga.miashs.album.model.Picture;

public class PictureService extends JpaService<Long,Picture> {

	public void create(Picture pic) throws ServiceException {
        pic.setAlbum(getEm().merge( pic.getAlbum()));
        super.create(pic);
    }
	

    @SuppressWarnings("unchecked")
	public List<Picture> listPictureByAlbum(long albumId) throws ServiceException {
    	System.out.println("debut requete");
        Query query = getEm().createNamedQuery("Picture.findByAlbum");
        query.setParameter("albumId", albumId);
        return query.getResultList();
    }
    
    public Picture getById(Integer id) {
        Query query = getEm().createNamedQuery("Picture.findById");
        query.setParameter("id", id);
        return (Picture) query.getSingleResult();
    }

}
