package fr.uga.miashs.album.util;

public interface Pages {
	public final static String add_album = "faces/add-album.xhtml";
	public final static String list_album = "faces/list-album.xhtml";
	public final static String album = "faces/album.xhtml";
	public final static String add_user = "faces/add-user.xhtml";
	public final static String list_user = "faces/list-user.xhtml";
	public final static String login = "faces/login.xhtml";
}
